package com.mycompany.c4aii_ferrian;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class Controller{
	  // Attributi
    private final View vista;
    
	// Costruttori
    public Controller(View vista) {
        this.vista = vista;
	
        vista.getBtnSalva().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Model.Articolo = vista.getTxtArticolo().getText();
                Model.Prezzo = Integer.parseInt(vista.getTxtPrezzo().getText());
                Model.Quantita = Integer.parseInt(vista.getTxtQuantita().getText());
                Model.Importo = Integer.parseInt(vista.getTxtImporto().getText());

                JOptionPane.showMessageDialog(null, "\nArticolo:\n" + Model.Articolo + "\nPrezzo:\n" + Model.Prezzo + "\nQuantita:\n" + Model.Quantita + "\nImporto:\n" + Model.Importo, "\nMessaggio:\n", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("a");
            
            }
        });
        vista.getBtnCalcola().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                
                int Q = Integer.parseInt(vista.getTxtQuantita().getText());
                int P = Integer.parseInt(vista.getTxtPrezzo().getText());
                int res = Q * P;
                vista.txtImporto.setText(Integer.toString(res));
                System.out.println("b");
            }
        });
        
    }
}