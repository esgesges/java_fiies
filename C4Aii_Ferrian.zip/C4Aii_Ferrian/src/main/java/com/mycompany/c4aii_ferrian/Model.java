/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.c4aii_ferrian;

/**
 *
 * @author s1009996
 */
public class Model {
    private final Controller controller;

    static String Articolo = "";
    static float Prezzo = 0, Quantita = 0, Importo = 0;
    
    public Model(Controller controller) {
        this.controller = controller;
        

    }
}
