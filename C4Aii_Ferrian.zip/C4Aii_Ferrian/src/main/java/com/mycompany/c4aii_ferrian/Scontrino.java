/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.c4aii_ferrian;

/**
 *
 * @author s1009996
 */
public class Scontrino {
    public static void main(String[] args){
        View view = new View("Scontrino");
        Controller controller = new Controller(view);

    }
}
