package com.mycompany.c4aii_ferrian;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class View {
    private JFrame finestra;
    private JPanel pannello;
    private JPanel btnPanel;
    private JPanel pannelloNumeri;
    private JLabel lblArticolo;
    private static JTextField txtArticolo;
    private JLabel lblPrezzo;
    private static JTextField txtPrezzo;
    private JLabel lblQuantita;
    private static JTextField txtQuantita;
    private JLabel lblImporto;
    static JTextField txtImporto;
    
    private JButton btnSalva;
    private JButton btnCalcola;
    
    public View (String titolo) {
        finestra = new JFrame(titolo);
        
        lblArticolo = new JLabel("Articolo");
        txtArticolo = new JTextField();
        
        lblPrezzo = new JLabel("Prezzo");
        txtPrezzo = new JTextField();
        
        lblQuantita = new JLabel("Quantita");
        txtQuantita = new JTextField();
        
        lblImporto = new JLabel("Importo");
        txtImporto = new JTextField();
        
        btnSalva = new JButton("Salva Model");
        btnCalcola = new JButton("Calcola");

        
        pannello = new JPanel();
        pannello.setLayout(new GridLayout(2, 2));
        btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(1,1));
        
        pannello.add(lblArticolo);
        pannello.add(txtArticolo);
        
        pannello.add(lblPrezzo);
        pannello.add(txtPrezzo);
        
        pannello.add(lblQuantita);
        pannello.add(txtQuantita);
        
        pannello.add(lblImporto);
        pannello.add(txtImporto);
        
        finestra.add(pannello, BorderLayout.NORTH);
        btnPanel.add(btnCalcola); 
        btnPanel.add(btnSalva);
        finestra.add(btnPanel, BorderLayout.SOUTH);
        
        finestra.setSize(400, 150);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        finestra.setVisible(true);
    }

    public JFrame getFinestra() {
        return finestra;
    }

    public void setFinestra(JFrame finestra) {
        this.finestra = finestra;
    }

    public JPanel getPannello() {
        return pannello;
    }

    public void setPannello(JPanel pannello) {
        this.pannello = pannello;
    }

    public JPanel getBtnPanel() {
        return btnPanel;
    }

    public void setBtnPanel(JPanel btnPanel) {
        this.btnPanel = btnPanel;
    }

    public JPanel getPannelloNumeri() {
        return pannelloNumeri;
    }

    public void setPannelloNumeri(JPanel pannelloNumeri) {
        this.pannelloNumeri = pannelloNumeri;
    }

    public JLabel getLblArticolo() {
        return lblArticolo;
    }

    public void setLblArticolo(JLabel lblArticolo) {
        this.lblArticolo = lblArticolo;
    }

    public static JTextField getTxtArticolo() {
        return txtArticolo;
    }

    public void setTxtArticolo(JTextField txtArticolo) {
        this.txtArticolo = txtArticolo;
    }

    public JLabel getLblPrezzo() {
        return lblPrezzo;
    }

    public void setLblPrezzo(JLabel lblPrezzo) {
        this.lblPrezzo = lblPrezzo;
    }

    public static JTextField getTxtPrezzo() {
        return txtPrezzo;
    }

    public void setTxtPrezzo(JTextField txtPrezzo) {
        this.txtPrezzo = txtPrezzo;
    }

    public JLabel getLblQuantita() {
        return lblQuantita;
    }

    public void setLblQuantita(JLabel lblQuantita) {
        this.lblQuantita = lblQuantita;
    }

    public static JTextField getTxtQuantita() {
        return txtQuantita;
    }

    public void setTxtQuantita(JTextField txtQuantita) {
        this.txtQuantita = txtQuantita;
    }

    public JLabel getLblImporto() {
        return lblImporto;
    }

    public void setLblImporto(JLabel lblImporto) {
        this.lblImporto = lblImporto;
    }

    public static JTextField getTxtImporto() {
        return txtImporto;
    }

    public void setTxtImporto(JTextField txtImporto) {
        this.txtImporto = txtImporto;
    }

    public JButton getBtnSalva() {
        return btnSalva;
    }

    public void setBtnSalva(JButton btnSalva) {
        this.btnSalva = btnSalva;
    }

    public JButton getBtnCalcola() {
        return btnCalcola;
    }

    public void setBtnCalcola(JButton btnCalcola) {
        this.btnCalcola = btnCalcola;
    }
    
   
}
