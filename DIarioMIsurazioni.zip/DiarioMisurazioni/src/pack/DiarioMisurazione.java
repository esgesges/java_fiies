package pack;

public class DiarioMisurazione {

}
