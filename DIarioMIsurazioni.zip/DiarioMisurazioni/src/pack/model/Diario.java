package pack.model;

public class Diario {

}
