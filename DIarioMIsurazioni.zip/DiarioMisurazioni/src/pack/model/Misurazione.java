package pack.model;

public class Misurazione {

}
