package singoloascoltatore;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ascoltatore implements ActionListener {
    // Attributo
    public Component c;

    // Costruttore
    public Ascoltatore (Component c) {
        this.c = c;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        c.setBackground(Color.red);
    }

}
