package singoloascoltatore;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Controller {
    // Attributi
    private View vista;
    
    // Costruttori
    public Controller(View vista) {
        this.vista = vista;
        
        //vista.getFinestra().getContentPane();
        vista.getBottoneRosso().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vista.getFinestra().getContentPane().setBackground(Color.red);
            }
        });
        
        vista.getBottoneNero().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vista.getFinestra().getContentPane().setBackground(Color.black);
            }
        });
    }
            
    // Metodi

    public View getVista() {
        return vista;
    }

    public void setVista(View vista) {
        this.vista = vista;
    } 
}
