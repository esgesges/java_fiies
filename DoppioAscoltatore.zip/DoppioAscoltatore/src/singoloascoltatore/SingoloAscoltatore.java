package singoloascoltatore;
public class SingoloAscoltatore {
    public static void main(String[] args) {
        View vista = new View("Singolo Bottone con ascoltatore");
        Controller controller = new Controller (vista);
    }    
}
