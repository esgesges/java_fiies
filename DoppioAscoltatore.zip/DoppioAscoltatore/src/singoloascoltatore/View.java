package singoloascoltatore;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

class View {
    // Attributi
    private JFrame finestra;
    private JButton bottoneRosso;
    private JButton bottoneNero;
    // Costruttore
    public View(String titolo) {
        this.finestra = new JFrame(titolo);
        this.bottoneRosso = new JButton("Rosso!");
        this.bottoneNero = new JButton("Nero!");
        finestra.getContentPane().add(bottoneRosso, BorderLayout.SOUTH);
        finestra.getContentPane().add(bottoneNero, BorderLayout.NORTH);
        finestra.setSize(400, 300);
        finestra.setDefaultCloseOperation(finestra.EXIT_ON_CLOSE);
        finestra.setVisible(true);               
    }

    public JFrame getFinestra() {
        return finestra;
    }

    public void setFinestra(JFrame finestra) {
        this.finestra = finestra;
    }

    public JButton getBottoneRosso() {
        return bottoneRosso;
    }

    public void setBottoneRosso(JButton bottoneRosso) {
        this.bottoneRosso = bottoneRosso;
    }

    public JButton getBottoneNero() {
        return bottoneNero;
    }

    public void setBottoneNero(JButton bottoneNero) {
        this.bottoneNero = bottoneNero;
    }
    
    
    

}
