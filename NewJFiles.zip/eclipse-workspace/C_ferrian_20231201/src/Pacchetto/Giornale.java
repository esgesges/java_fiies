package Pacchetto;

public class Giornale extends MaterialeInformativo{
	String nome = "";
	int numPagine = 0, numArticoli = 0, costo = 0;
	public int getNumPagine(int numPagine) {
		
		return numPagine;
	}
	public Giornale(String nome, int numArticoli, int numPagine, int costo) {
		this.nome = nome;
		this.numArticoli = numArticoli;
		this.numPagine = numPagine;
		this.costo = costo;
	}
}
