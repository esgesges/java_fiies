package Pacchetto;

public class Libreria {
	
	public int[] RaccNumPagine() {
		int[] arrNumPagine = null;
		Libro a = null;
		Rivista b = null;
		Giornale c = null;
		arrNumPagine[0] = a.getNumPagine();
		arrNumPagine[1] = b.getNumPagine();
		arrNumPagine[2] = c.getNumPagine();

		return arrNumPagine;
	}
}
