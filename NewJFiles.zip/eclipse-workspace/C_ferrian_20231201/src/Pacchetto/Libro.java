package Pacchetto;

public class Libro extends MaterialeInformativo{
	String nome = "", editore = "";
	int numPagine = 0, costo = 0;
	
	public int getNumPagine() {
		return numPagine;
	}

	public Libro(String nome, String editore, int numPagine, int costo) {
		this.nome = nome;
		this.editore = editore;
		this.numPagine = numPagine;
		this.costo = costo;
	}
}
