package Pacchetto;

public class Main {
	private static Libreria d;

	public static void main(String[] args) {
		Libro a = new Libro("giust", "giorgio", 123, 12);
		Rivista b = new Rivista("gist", "mensile", 123, 12);
		Giornale c = new Giornale("giust", 7, 123, 12);
		d = null;
		int[] arr;
		arr = d.RaccNumPagine();
		for(int i = 0; i < 3; i++) {
			System.out.println(arr[i]);
		}
	}
}
