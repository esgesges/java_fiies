package Pacchetto;

public class MaterialeInformativo {
	String nome = "";
	int numPagine = 0;
	public int getNumPagine() {
		return 0;
	}
}