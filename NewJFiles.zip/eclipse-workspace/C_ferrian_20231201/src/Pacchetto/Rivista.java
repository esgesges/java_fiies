package Pacchetto;

public class Rivista extends MaterialeInformativo{
	String nome = "", periodicita = "";
	int numPagine = 0, costo = 0;
	public int getNumPagine(int numPagine) {
		
		return numPagine;
	}
	public Rivista(String nome, String periodicita, int numPagine, int costo) {
		this.nome = nome;
		this.periodicita = periodicita;
		this.numPagine = numPagine;
		this.costo = costo;
	}
}
