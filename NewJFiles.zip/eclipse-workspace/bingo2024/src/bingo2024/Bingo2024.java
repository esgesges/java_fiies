package bingo2024;
public class Bingo2024 {

}
