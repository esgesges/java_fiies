package bingo2024;

import java.awt.*;

public class View {
	
}
