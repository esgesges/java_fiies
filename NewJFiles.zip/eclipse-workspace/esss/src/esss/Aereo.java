package esss;

public class Aereo extends MezziDiTrasporto{
	int numeroMembriEquipaggio = 0;
	int quotaMassima = 0;
	
}
