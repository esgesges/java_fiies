package esss;

public abstract class AutoMezzo extends MezziDiTrasporto{
	public AutoMezzo() {
	//	super(VelocitaAttuale);
			
	}

	int tipoPatente = -1;
	
	
}
