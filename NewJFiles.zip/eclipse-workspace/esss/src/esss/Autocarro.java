package esss;

public class Autocarro extends AutoMezzo{

}
