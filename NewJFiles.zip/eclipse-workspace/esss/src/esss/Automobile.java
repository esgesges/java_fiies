package esss;

public class Automobile extends AutoMezzo{

	public Automobile(int VelocitaAttuale, int velocitaPotenziale) {
		this.velocitaAttuale = VelocitaAttuale;
		this.velocitaPotenziale = velocitaPotenziale;
	}
	
}
