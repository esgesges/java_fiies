package esss;

public class Main {
	public static void main(String[] args) {
		Automobile a = new Automobile(12,34);
		int b = a.velocitaPotenziale();
		
		System.out.println(b);

		
		
		
		
		
		
		
	}
	
}
