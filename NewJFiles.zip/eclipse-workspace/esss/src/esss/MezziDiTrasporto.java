package esss;

public abstract class MezziDiTrasporto {
	int numeroPosti = 0;
	String descrizioneMotore = "";
	int velocitaAttuale = 0;
	int velocitaPotenziale = 0;
	public MezziDiTrasporto(){
		//this.velocitaAttuale = VelocitaAttuale;
	
	}
	public int velocitaPotenziale(int a, int b) {
		int c = b-a;
		return c;
	}
	public int getVelocitaAttuale() {
		return velocitaAttuale;
	}
	public void setVelocitaAttuale(int velocitaAttuale) {
		this.velocitaAttuale = velocitaAttuale;
	}
	
			
	
}
