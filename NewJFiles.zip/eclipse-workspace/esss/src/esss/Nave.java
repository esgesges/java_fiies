package esss;

public class Nave extends MezziDiTrasporto{

	int numeroMembriEquipaggio = 0;
	int pescazzioMetri = 0;
	
		
}
