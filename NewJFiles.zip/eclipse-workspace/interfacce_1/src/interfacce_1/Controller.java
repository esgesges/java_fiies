package interfacce_1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class Controller {
	  // Attributi
    private View vista;
    public static int ris = 0;
    public static int liveNum = 0;
    public static int a = 0;
    public static int b = 0;
    public static int op = 0;
 
	// Costruttori
    public Controller(View vista) {
        this.vista = vista;
        
        vista.getN1().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 1;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN2().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 2;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN3().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 3;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN4().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 4;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN5().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 5;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN6().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 6;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN7().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 7;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN8().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 8;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getN9().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				liveNum = liveNum * 10 + 9;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getSum().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				a = liveNum;
				liveNum = 0;
				op = 1;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getSott().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				a = liveNum;
				liveNum = 0;
				op = 2;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getMolt().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				a = liveNum;
				liveNum = 0;
				op = 3;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getDiv().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				a = liveNum;
				liveNum = 0;
				op = 4;
				vista.getTxtRis().setText("" + liveNum);
			}
        });
        vista.getEq().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				b = liveNum;
				switch(op) {
				
				case 1:
					int ris = a + b;
					vista.getVuoto().setText("" + ris);
					liveNum = 0;
					a = 0;
					b = 0;
				break;
				case 2:
					ris = a - b;
					vista.getVuoto().setText("" + ris);
					liveNum = 0;
					a = 0;
					b = 0;
				break;
				case 3:
					ris = a * b;
					vista.getVuoto().setText("" + ris);
					liveNum = 0;
					a = 0;
					b = 0;
				break;
				case 4:
					ris = a / b;
					vista.getVuoto().setText("" + ris);
					liveNum = 0;
					a = 0;
					b = 0;
				break;
				
				
				
				
				}
			}
        });
        
        
    }
    public static int getRis() {
		return ris;
	}
	public static void setRis(int ris) {
		Controller.ris = ris;
	}
}