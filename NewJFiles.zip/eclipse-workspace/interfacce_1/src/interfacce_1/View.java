package interfacce_1;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;


public class View {
	int ris = Controller.getRis();
	
				
	public static JButton 
		N1;


	public static JButton N2;


	public JButton N3;
	

	public JButton N4;


	public JButton N5;


	public JButton N6;


	public JButton N7;


	public JButton N8;


	public JButton N9;


	public JButton Sum;


	public JButton Sott;


	public JButton Molt;


	public JButton Div;

	
	
	public JButton Eq;
	
	
	public JButton vuoto;
	public JButton vuoto2;
	public JButton vuoto3;
	public JButton vuoto4;
	public JButton vuoto5;
	
	public JTextField txtRis;
	
	
	private JFrame finestra;
	
	public View(String titolo) {
		
		finestra = new JFrame(titolo);
		
		N1 = new JButton("1");
		N2 = new JButton("2");
		N3 = new JButton("3");
		N4 = new JButton("4");
		N5 = new JButton("5");
		N6 = new JButton("6");
		N7 = new JButton("7");
		N8 = new JButton("8");
		N9 = new JButton("9");
		Sum = new JButton("+");
		Sott = new JButton("-");
		Molt = new JButton("X");
		Div = new JButton("/");
		Eq = new JButton("=");
		vuoto = new JButton("");
		vuoto2 = new JButton("");
		vuoto3 = new JButton("");
		vuoto4 = new JButton("");
		vuoto5 = new JButton("");
		txtRis = new JTextField("");
		
		
        N1.setHorizontalAlignment(SwingConstants.CENTER);
        N2.setHorizontalAlignment(SwingConstants.CENTER);
        N3.setHorizontalAlignment(SwingConstants.CENTER);
        N4.setHorizontalAlignment(SwingConstants.CENTER);
        N5.setHorizontalAlignment(SwingConstants.CENTER);
        N5.setHorizontalAlignment(SwingConstants.CENTER);
        N7.setHorizontalAlignment(SwingConstants.CENTER);
        N8.setHorizontalAlignment(SwingConstants.CENTER);
        N9.setHorizontalAlignment(SwingConstants.CENTER);
        Sum.setHorizontalAlignment(SwingConstants.CENTER);
        Sott.setHorizontalAlignment(SwingConstants.CENTER);
        Molt.setHorizontalAlignment(SwingConstants.CENTER);
        Div.setHorizontalAlignment(SwingConstants.CENTER);
        Sum.setHorizontalAlignment(SwingConstants.CENTER);
		
		getFinestra().setSize(300, 500);
        getFinestra().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container c = getFinestra().getContentPane();
        c.setLayout(new GridLayout(5,4));
                     

        c.add(vuoto2);
        c.add(vuoto4);
        c.add(txtRis);
        c.add(vuoto);
        c.add(N1);
        c.add(N2);
        c.add(N3);
        c.add(Sum);
        c.add(N4);
        c.add(N5);
        c.add(N6);
        c.add(Sott);
        c.add(N7);
        c.add(N8);
        c.add(N9);       
        c.add(Molt);
        c.add(vuoto3);
        c.add(vuoto5);
        c.add(Eq);
        c.add(Div);
        finestra.setVisible(true);  
	}



	public JButton getEq() {
		return Eq;
	}



	public void setEq(JButton eq) {
		Eq = eq;
	}



	public JButton getVuoto() {
		return vuoto;
	}



	public void setVuoto(JButton vuoto) {
		this.vuoto = vuoto;
	}



	public JTextField getTxtRis() {
		return txtRis;
	}



	public void setTxtRis(JTextField txtRis) {
		this.txtRis = txtRis;
	}



	public static JButton getN1() {
		return N1;
	}



	public void setN1(JButton n1) {
		N1 = n1;
	}



	public static JButton getN2() {
		return N2;
	}



	public void setN2(JButton n2) {
		N2 = n2;
	}



	public JButton getN3() {
		return N3;
	}



	public void setN3(JButton n3) {
		N3 = n3;
	}



	public JButton getN4() {
		return N4;
	}



	public void setN4(JButton n4) {
		N4 = n4;
	}



	public JButton getN5() {
		return N5;
	}



	public void setN5(JButton n5) {
		N5 = n5;
	}



	public JButton getN6() {
		return N6;
	}



	public void setN6(JButton n6) {
		N6 = n6;
	}



	public JButton getN7() {
		return N7;
	}



	public void setN7(JButton n7) {
		N7 = n7;
	}



	public JButton getN8() {
		return N8;
	}



	public void setN8(JButton n8) {
		N8 = n8;
	}



	public JButton getN9() {
		return N9;
	}



	public void setN9(JButton n9) {
		N9 = n9;
	}



	public JButton getSott() {
		return Sott;
	}



	public void setSott(JButton sott) {
		Sott = sott;
	}



	public JButton getMolt() {
		return Molt;
	}



	public void setMolt(JButton molt) {
		Molt = molt;
	}



	public JButton getDiv() {
		return Div;
	}



	public void setDiv(JButton div) {
		Div = div;
	}


	public JButton getSum() {
		return Sum;
	}



	public void setSum(JButton sum) {
		Sum = sum;
	}



	public JFrame getFinestra() {
		return finestra;
	}

	public void setFinestra(JFrame finestra) {
		this.finestra = finestra;
	}

}
