/**
 * 
 */
/**
 * 
 */
module interfacce_1 {
	requires java.desktop;
}