package ripasso;

public class Classe2 {
	String p;
	int r;
	
	
	
	
	public String getP() {
		return p;
	}




	public void setP(String p) {
		this.p = p;
	}




	public int getR() {
		return r;
	}




	public void setR(int r) {
		this.r = r;
	}

	public void print() {
	System.out.println(r + "\n" + p);
	}
}
