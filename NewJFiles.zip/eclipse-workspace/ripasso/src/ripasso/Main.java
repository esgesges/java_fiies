package ripasso;

public class Main extends Classe2{

	public static void main(String[] args) {
		String f = "asdadadddddddddddddd";
		
		
		Classe2 ogg = new Classe2();
		ogg.setP(f);
		ogg.setR(45);		
		
		String a = ogg.getP();
		int b = ogg.getR();
		System.out.println(a + "\n" + b);
		//ogg.print();
				
	}

}
