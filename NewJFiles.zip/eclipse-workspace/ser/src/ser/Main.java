package ser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
        View view = new View("Input dati");

        Persona primoUtente = new Persona("Verdi", "Giovanni", "verdi@gmail.com", 2006, 12, 1);
        Persona utenteLetto = null;
        
        
        
//---------------------------------------------------------------------------------------------------------------------
        
        
        
        FileOutputStream fileOutputStream;
        try {
            fileOutputStream = new FileOutputStream("persona1.txt");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(primoUtente);
            objectOutputStream.flush();
            objectOutputStream.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("SCRITTURA AVVENUTA");
        
        
        
//---------------------------------------------------------------------------------------------------------------------
        
        
        
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream("persona1.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            utenteLetto = (Persona) objectInputStream.readObject();
            objectInputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("LETTURA AVVENUTA");
        
        System.out.println(utenteLetto);
    }
}
