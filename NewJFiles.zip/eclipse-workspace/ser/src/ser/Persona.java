
package ser;

import java.io.Serializable;

public class Persona implements Serializable{
    private String cognome;
    private String nome;
    private String email;
    private int annoNascita;
    private int meseNascita;
    private int giornoNascita;

    public Persona(String cognome, String nome, String email, int annoNascita, int meseNascita, int giornoNascita) {
        this.cognome = cognome;
        this.nome = nome;
        this.email = email;
        this.annoNascita = annoNascita;
        this.meseNascita = meseNascita;
        this.giornoNascita = giornoNascita;
    }

    @Override
    public String toString() {
        return "Persona{" + "cognome=" + cognome + ",\n nome=" + nome + ",\n email=" + email + ",\n annoNascita=" + annoNascita + ",\n meseNascita=" + meseNascita + ",\n giornoNascita=" + giornoNascita + '}';
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAnnoNascita() {
        return annoNascita;
    }

    public void setAnnoNascita(int annoNascita) {
        this.annoNascita = annoNascita;
    }

    public int getMeseNascita() {
        return meseNascita;
    }

    public void setMeseNascita(int meseNascita) {
        this.meseNascita = meseNascita;
    }

    public int getGiornoNascita() {
        return giornoNascita;
    }

    public void setGiornoNascita(int giornoNascita) {
        this.giornoNascita = giornoNascita;
    }
    
    
}
