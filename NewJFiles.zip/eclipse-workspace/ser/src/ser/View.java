package ser;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class View {
    private JFrame finestra;
    private Component sfondo;
    
    private JLabel lblNome;
    private JTextField txtNome;
    
    private JLabel lblCognome;
    private JTextField txtCognome;
    
    private JLabel lblEmail;
    private JTextField txtEmail;
    
    private JLabel lblGustoPanino;
    private JTextField txtGustoPanino;
    
    private JPanel pannelloTesti;
    private JButton btnInoltra;

    // Costruttore
    public View(String titolo) {
        finestra = new JFrame(titolo);
        sfondo = finestra.getContentPane();
        pannelloTesti = new JPanel();
        pannelloTesti.setLayout(new GridLayout(4, 2)); // 4 righe x 2 colonne
        btnInoltra = new JButton("Inoltra!");
        
        lblNome = new JLabel("Nome: ");
        pannelloTesti.add(lblNome);
        
        txtNome = new JTextField();
        pannelloTesti.add(txtNome);
        
        lblCognome = new JLabel("Cognome: ");
        pannelloTesti.add(lblCognome);
        
        txtCognome = new JTextField();
        pannelloTesti.add(txtCognome);
        
         lblEmail = new JLabel("Email: ");
        pannelloTesti.add(lblEmail);
        
        txtEmail = new JTextField();
        pannelloTesti.add(txtEmail);
        
         lblGustoPanino = new JLabel("Gusto Panino: ");
        pannelloTesti.add(lblGustoPanino);
        
        txtGustoPanino = new JTextField();
        pannelloTesti.add(txtGustoPanino);        
        
        
        finestra.add(pannelloTesti, BorderLayout.NORTH);
        finestra.add(btnInoltra, BorderLayout.SOUTH);
        finestra.setSize(350, 170);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
        finestra.setVisible(true);
    }
    
    
    // Metodi getter e setter

    public JFrame getFinestra() {
        return finestra;
    }

    public void setFinestra(JFrame finestra) {
        this.finestra = finestra;
    }

    public Component getSfondo() {
        return sfondo;
    }

    public void setSfondo(Component sfondo) {
        this.sfondo = sfondo;
    }

    public JLabel getLblNome() {
        return lblNome;
    }

    public void setLblNome(JLabel lblNome) {
        this.lblNome = lblNome;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public void setTxtNome(JTextField txtNome) {
        this.txtNome = txtNome;
    }

    public JLabel getLblCognome() {
        return lblCognome;
    }

    public void setLblCognome(JLabel lblCognome) {
        this.lblCognome = lblCognome;
    }

    public JTextField getTxtCognome() {
        return txtCognome;
    }

    public void setTxtCognome(JTextField txtCognome) {
        this.txtCognome = txtCognome;
    }

    public JLabel getLblEmail() {
        return lblEmail;
    }

    public void setLblEmail(JLabel lblEmail) {
        this.lblEmail = lblEmail;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public void setTxtEmail(JTextField txtEmail) {
        this.txtEmail = txtEmail;
    }

    public JLabel getLblGustoPanino() {
        return lblGustoPanino;
    }

    public void setLblGustoPanino(JLabel lblGustoPanino) {
        this.lblGustoPanino = lblGustoPanino;
    }

    public JTextField getTxtGustoPanino() {
        return txtGustoPanino;
    }

    public void setTxtGustoPanino(JTextField txtGustoPanino) {
        this.txtGustoPanino = txtGustoPanino;
    }

    public JPanel getPannelloTesti() {
        return pannelloTesti;
    }

    public void setPannelloTesti(JPanel pannelloTesti) {
        this.pannelloTesti = pannelloTesti;
    }

    public JButton getBtnInoltra() {
        return btnInoltra;
    }

    public void setBtnInoltra(JButton btnInoltra) {
        this.btnInoltra = btnInoltra;
    }    
}
