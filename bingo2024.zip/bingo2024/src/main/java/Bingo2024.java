/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author s1009996
 */
public class Bingo2024 {

    public static void main(String[] args) {
         View finestra = new View("sommatore");
        Controller controller = new Controller(finestra);  
    }
}
