import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class Controller{
	  // Attributi
    private final View vista;
    public static int ris = 0;
    String Nome = "", Cognome = "";
    int n1,n2,n3,n4,n5,n6;

    
	// Costruttori
    public Controller(View vista) {
        this.vista = vista;
	
        vista.getBtnInvia().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                
                Nome = vista.getTxtNome().getText();
                Cognome = vista.getTxtCognome().getText();
                n1 = Integer.parseInt(vista.getTxtN1().getText());
                n2 = Integer.parseInt(vista.getTxtN2().getText());
                n3 = Integer.parseInt(vista.getTxtN3().getText());
                n4 = Integer.parseInt(vista.getTxtN4().getText());
                n5 = Integer.parseInt(vista.getTxtN5().getText());
                n6 = Integer.parseInt(vista.getTxtN6().getText());
                JLabel.
            }
        });
        
    }
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String Cognome) {
        this.Cognome = Cognome;
    }

    public int getN1() {
        return n1;
    }

    public void setN1(int n1) {
        this.n1 = n1;
    }

    public int getN2() {
        return n2;
    }

    public void setN2(int n2) {
        this.n2 = n2;
    }

    public int getN3() {
        return n3;
    }

    public void setN3(int n3) {
        this.n3 = n3;
    }

    public int getN4() {
        return n4;
    }

    public void setN4(int n4) {
        this.n4 = n4;
    }

    public int getN5() {
        return n5;
    }

    public void setN5(int n5) {
        this.n5 = n5;
    }

    public int getN6() {
        return n6;
    }

    public void setN6(int n6) {
        this.n6 = n6;
    }
}