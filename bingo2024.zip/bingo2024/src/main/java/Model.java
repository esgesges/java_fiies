/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author s1009996
 */
public class Model {
    private final Controller controller;

    String Nome = "", Cognome = "";
    
    public Model(Controller controller) {
        this.controller = controller;
        int n1 = controller.getN1(),
            n2 = controller.getN1(),
            n3 = controller.getN1(),
            n4 = controller.getN1(),
            n5 = controller.getN1(),
            n6 = controller.getN1();
        String Nome = controller.getNome(),
               Cognome = controller.getCognome();

    }
    
}
