import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class View {
    private JFrame finestra;
    private JPanel pannello;
    private JPanel pannelloNumeri;
    private JLabel lblNome;
    private JTextField txtNome;
    private JLabel lblCognome;
    private JTextField txtCognome;
    private JLabel lblNumeri;
    private JTextField txtN1;
    private JTextField txtN2;
    private JTextField txtN3;
    private JTextField txtN4;
    private JTextField txtN5;
    private JTextField txtN6;
    private JButton btnInvia;
    
    public View (String titolo) {
        finestra = new JFrame(titolo);
        
        lblNome = new JLabel("Nome: ");
        txtNome = new JTextField();
        
        lblCognome = new JLabel("Cognome");
        txtCognome = new JTextField();
        
        lblNumeri = new JLabel("Numeri giocati: ");
        txtN1 = new JTextField();
        txtN2 = new JTextField();
        txtN3 = new JTextField();
        txtN4 = new JTextField();
        txtN5 = new JTextField();
        txtN6 = new JTextField();
        
        btnInvia = new JButton("Invia!");
        
        pannello = new JPanel();
        pannello.setLayout(new GridLayout(3, 2));
        
        pannelloNumeri = new JPanel();
        pannelloNumeri.setLayout(new GridLayout(1, 7));
        
        pannelloNumeri.add(lblNumeri);
        pannelloNumeri.add(txtN1);
        pannelloNumeri.add(txtN2);
        pannelloNumeri.add(txtN3);
        pannelloNumeri.add(txtN4);
        pannelloNumeri.add(txtN5);
        pannelloNumeri.add(txtN6);
        
        pannello.add(lblNome);
        pannello.add(txtNome);
        
        pannello.add(lblCognome);
        pannello.add(txtCognome);
        
        pannello.add(lblNumeri);
        pannello.add(pannelloNumeri);
        
        finestra.add(pannello, BorderLayout.NORTH);
        finestra.add(btnInvia, BorderLayout.SOUTH); 
        
        finestra.setSize(400, 150);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        finestra.setVisible(true);
    }
    
    // Metodi getter e setter

    public JFrame getFinestra() {
        return finestra;
    }

    public void setFinestra(JFrame finestra) {
        this.finestra = finestra;
    }

    public JPanel getPannello() {
        return pannello;
    }

    public void setPannello(JPanel pannello) {
        this.pannello = pannello;
    }

    public JPanel getPannelloNumeri() {
        return pannelloNumeri;
    }

    public void setPannelloNumeri(JPanel pannelloNumeri) {
        this.pannelloNumeri = pannelloNumeri;
    }

    public JLabel getLblNome() {
        return lblNome;
    }

    public void setLblNome(JLabel lblNome) {
        this.lblNome = lblNome;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public void setTxtNome(JTextField txtNome) {
        this.txtNome = txtNome;
    }

    public JLabel getLblCognome() {
        return lblCognome;
    }

    public void setLblCognome(JLabel lblCognome) {
        this.lblCognome = lblCognome;
    }

    public JTextField getTxtCognome() {
        return txtCognome;
    }

    public void setTxtCognome(JTextField txtCognome) {
        this.txtCognome = txtCognome;
    }

    public JLabel getLblNumeri() {
        return lblNumeri;
    }

    public void setLblNumeri(JLabel lblNumeri) {
        this.lblNumeri = lblNumeri;
    }

    public JTextField getTxtN1() {
        return txtN1;
    }

    public void setTxtN1(JTextField txtN1) {
        this.txtN1 = txtN1;
    }

    public JTextField getTxtN2() {
        return txtN2;
    }

    public void setTxtN2(JTextField txtN2) {
        this.txtN2 = txtN2;
    }

    public JTextField getTxtN3() {
        return txtN3;
    }

    public void setTxtN3(JTextField txtN3) {
        this.txtN3 = txtN3;
    }

    public JTextField getTxtN4() {
        return txtN4;
    }

    public void setTxtN4(JTextField txtN4) {
        this.txtN4 = txtN4;
    }

    public JTextField getTxtN5() {
        return txtN5;
    }

    public void setTxtN5(JTextField txtN5) {
        this.txtN5 = txtN5;
    }

    public JTextField getTxtN6() {
        return txtN6;
    }

    public void setTxtN6(JTextField txtN6) {
        this.txtN6 = txtN6;
    }

    public JButton getBtnInvia() {
        return btnInvia;
    }

    public void setBtnInvia(JButton btnInvia) {
        this.btnInvia = btnInvia;
    }
    
}
