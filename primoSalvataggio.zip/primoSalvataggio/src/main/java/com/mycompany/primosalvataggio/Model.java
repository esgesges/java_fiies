/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.primosalvataggio;

/**
 *
 * @author s1009996
 */
public class Model {
    String Nome,
           Cognome,
           email;
    int    annoNascita,
           meseNascita,
           giornoNascita;
    public Model(String Nome, String Cognome, String Email, int annoNascita, int meseNascita, int giornoNascita){
        
    }
}
