/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primosalvataggio;

/**
 *
 * @author s1009996
 */
public class PrimoSalvataggio {

    public static void main(String[] args) {
        Model primoUtente = new Model("giorgio", "fdfsd", "dasdasd@gmail.com", 1965, 11, 24);
    }
}
