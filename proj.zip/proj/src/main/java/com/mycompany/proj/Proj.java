/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proj;

/**
 *
 * @author s1009996
 */
public class Proj {

    public static void main(String[] args) {
        View v = new View("slotmachine");
    }
}
