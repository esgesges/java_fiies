package com.mycompany.proj;
import java.awt.*;
import static java.awt.BorderLayout.EAST;
import static java.awt.BorderLayout.WEST;
import javax.swing.*;


class View {
    private JFrame finestra;
    private JPanel objDisplay;
    private JPanel spinButton;
    private JPanel secButtons;
    private JPanel WCpanel;
    private JPanel betPanel;
    
    //objDisplay
    private JTextArea sp1;
    private JTextArea sp2;
    private JTextArea sp3;
    
    //spinButton
    private JButton Bspin;
       
    //secButtons
    private JTextField Twin;
    private JTextField Tbet;
    private JTextField Tcred;
    private JButton addBet;
    private JButton subBet;
    
    public View (String titolo) {
        finestra = new JFrame(titolo);
        objDisplay = new JPanel();
               
        
        
        
        
        
        
        
        
        objDisplay.setLayout(new GridLayout(1, 3));
        objDisplay.add(sp1);
        objDisplay.add(sp2);
        objDisplay.add(sp3);
        
        spinButton.add(Bspin);
        
        secButtons.setLayout(new BorderLayout());
        secButtons.add(WCpanel, WEST);
        secButtons.add(betPanel, EAST);
        
        WCpanel.setLayout(new BoxLayout(WCpanel, BoxLayout.Y_AXIS));
        WCpanel.add(Twin);
        WCpanel.add(Tcred);
        
        betPanel.setLayout(new BoxLayout(betPanel, BoxLayout.Y_AXIS));
        betPanel.add(addBet);
        betPanel.add(Tbet);
        betPanel.add(subBet);
        
        betPanel.
        finestra.setLayout();
        finestra.setSize(400, 150);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        finestra.setVisible(true);
    }
    
}
